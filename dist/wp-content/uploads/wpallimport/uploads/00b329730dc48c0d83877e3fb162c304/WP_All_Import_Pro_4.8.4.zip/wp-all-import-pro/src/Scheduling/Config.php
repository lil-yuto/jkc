<?php

namespace Wpai\Scheduling;

/**
 * Class Config
 * @package Wpai\Scheduling
 */
class Config
{
    /**
     *
     */
    const TYPE = 'import';
    /**
     *
     */
    const API_URL = 'http://scheduling.wpallimport.com/v1';
}